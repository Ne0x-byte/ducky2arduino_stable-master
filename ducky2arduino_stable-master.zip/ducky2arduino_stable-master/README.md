Project is live. Goto http://roothaxor.gitlab.io/ducky2arduino_stable/

Simple RubberDucky Script to Arduino Script/Skecth Converter.
ant issue/problem contact here : https://roothaxor.github.io/contact.htm